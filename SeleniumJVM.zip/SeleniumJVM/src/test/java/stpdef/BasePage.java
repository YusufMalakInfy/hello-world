package stpdef;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;

public class BasePage {
	
	public static WebDriver driver;
	
	//WebDriverWait wait= new WebDriverWait(driver, 30);

@Before
/**
 * Delete all cookies at the start of each scenario to avoid
 * shared state between tests
 */
public  void openBrowser() throws IOException {
	String browserName = PropertyFileUtils.getProperty("Browser");
	if (browserName.equalsIgnoreCase("Chrome")) {
		System.out.println("Called openBrowser==>"+browserName);
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\bajarangi.chaurasia\\Desktop\\chromedriver.exe");
		driver = new ChromeDriver();
		/*driver.manage().deleteAllCookies();
		driver.manage().window().maximize();*/
	
	} else if (browserName.equalsIgnoreCase("IE")) {
		System.out.println("Called openBrowser");
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\bajarangi.chaurasia\\Desktop\\IEdriver.exe");
		driver = new ChromeDriver();
	/*	driver.manage().deleteAllCookies();
		driver.manage().window().maximize();*/
		
		
	} else if (browserName.equalsIgnoreCase("Firefox")) {
		System.out.println("Called openBrowser===>"+browserName);
		System.setProperty("webdriver.firefox.bin",
				"C:\\Program Files (x86)\\Mozilla Firefox\\firefox.exe");
		driver = new FirefoxDriver();
		
	
	
	}
	driver.manage().deleteAllCookies();
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
}

@After
/**
 * Embed a screenshot in test report if test is marked as failed
 */
//public void embedScreenshot(Scenario scenario) throws IOException {
	public  void captureScreenShot(Scenario scenario) throws IOException{
	
	System.out.println("test case status==="+scenario.getStatus().equals("passed"));
	
	if (scenario.getStatus().equals("passed"))
	{
	
		 File sb=	FileFolderCreationUtils.folderCreation("Pass");
			
			//String ds=	System.getProperty("user.dir")+"\\TestResultScreenShot\\fail\\"+result.getName()+".png";
			String ds=	sb+"\\"+scenario.getName()+".png";
			System.out.println("screenshaot name=="+ds);
			File destfile = new File(ds);
			try {
				 File fs=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
				 FileUtils.copyFile(fs, destfile);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

	
	}
	
	
	if (scenario.getStatus().equals("failed"))
	{
	
		 File sb=	FileFolderCreationUtils.folderCreation("Fail");
			
			//String ds=	System.getProperty("user.dir")+"\\TestResultScreenShot\\fail\\"+result.getName()+".png";
			String ds=	sb+"\\"+scenario.getName()+".png";
			System.out.println("screenshaot name=="+ds);
			File destfile = new File(ds);
			try {
				 File fs=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
				 FileUtils.copyFile(fs, destfile);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

	
	}

/*System.out.println(scenario.getName());
System.out.println(scenario.getStatus().equals("passed"));
System.out.println(scenario.getStatus().equals("failed"));
System.out.println(scenario.getName());
System.out.println(scenario.getName());*/
/*
Print title, url
false
true
Print title, url
Print title, url*/
	if (scenario.isFailed()) {
		
		try {
			scenario.write("Current Page URL is " + driver.getCurrentUrl());
			// byte[] screenshot = getScreenshotAs(OutputType.BYTES);
			byte[] screenshot = ((TakesScreenshot) driver)
					.getScreenshotAs(OutputType.BYTES);
			scenario.embed(screenshot, "image/png");
		} catch (WebDriverException somePlatformsDontSupportScreenshots) {
			System.err.println(somePlatformsDontSupportScreenshots
					.getMessage());
		}

	}
	driver.quit();

}

}