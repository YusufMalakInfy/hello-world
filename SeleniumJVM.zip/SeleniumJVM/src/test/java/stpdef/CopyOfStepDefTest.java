package stpdef;


import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;



import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CopyOfStepDefTest {
	
	public  WebDriver driver;
	public CopyOfStepDefTest()
    {
    	driver = BasePage.driver;
    }

	
	@When("^I open seleniumframework website$")
	public void i_open_seleniumframework_website() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 driver.get("https://www.google.com");
		 
	     boolean  status = driver.findElement(By.name("q")).isDisplayed();
	if(!status==false)
		driver.findElement(By.name("q")).sendKeys("selenioumm");

	}

	@Then("^I validate title and URL$")
	public void i_validate_title_and_URL() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("currenturl====>"+driver.getCurrentUrl());
		Assert.assertTrue(driver.getCurrentUrl().contains("selenium"));
	}


    }




