package stpdef;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;



import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class facebookstep {
	
	
	public   WebDriver driver;
	//WebDriverWait wait = new WebDriverWait(driver, 30);

	public facebookstep() {
		driver = BasePage.driver;
	}


@Given("^launch the \"([^\"]*)\"$")
public void launch_the(String arg1) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    System.out.println("application laucvhed");
}

@Given("^Navigate to facebook site$")
public void navigate_to_facebook_site() throws Throwable {
    // Write code here that turns the phrase above into concrete actions

	driver.get("https://www.facebook.com");
}

@When("^I enter the username$")
public void i_enter_the_username() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	WebDriverWait wait = new WebDriverWait(driver, 30);
	wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.cssSelector("#email"))));
	WebElement loginpage_username = driver.findElement(By
			.cssSelector("#email"));
	try {
		loginpage_username.isDisplayed();
		loginpage_username.clear();
		loginpage_username.sendKeys("immaculatebajju@gmail.com");
	} catch (Exception e) {
		System.out.println("user name field is not dispalyed");
	}

}

@When("^I enter the password$")
public void i_enter_the_password() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	WebDriverWait wait = new WebDriverWait(driver, 30);
	wait.until(ExpectedConditions.visibilityOf(driver.findElement(By
			.cssSelector("#pass"))));
	WebElement loginpage_password = driver.findElement(By
			.cssSelector("#pass"));
	try {
		loginpage_password.isDisplayed();
		loginpage_password.clear();
		loginpage_password.sendKeys("soni@21");
	} catch (Exception e) {
		System.out.println("password field is not dispalyed");
	}
}

@When("^Click on login button$")
public void click_on_login_button() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	WebDriverWait wait = new WebDriverWait(driver, 30);
	wait.until(ExpectedConditions.visibilityOf(driver.findElement(By
			.cssSelector("#loginbutton"))));
	WebElement loginpage_loginbutton = driver.findElement(By
			.cssSelector("#loginbutton"));
	try {
		loginpage_loginbutton.isDisplayed();
		loginpage_loginbutton.clear();
		loginpage_loginbutton.sendKeys("soni@21");
		Thread.sleep(5000);
	} catch (Exception e) {
		System.out.println("login button is not dispalyed");
	}
}

@Then("^Home page should be displayed$")
public void home_page_should_be_displayed() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	String currenturl = driver.getCurrentUrl();
	System.out.println("afterlogin url:" + currenturl);
	Assert.assertTrue(driver.getCurrentUrl().contains("facebook"));
}

@When("^I enter the username \"([^\"]*)\"$")
public void i_enter_the_username(String userName) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	WebElement loginpage_username = driver.findElement(By
			.cssSelector("#email"));
	try {
		loginpage_username.isDisplayed();
		loginpage_username.clear();
		loginpage_username.sendKeys(userName);
	} catch (Exception e) {
		System.out.println("user name field is not dispalyed");
	}

}

@When("^I enter the username \"([^\"]*)\" in step$")
public void i_enter_the_username_in_step(String password) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	WebElement loginpage_password = driver.findElement(By
			.cssSelector("#pass"));
	try {
		loginpage_password.isDisplayed();
		loginpage_password.clear();
		loginpage_password.sendKeys(password);
	} catch (Exception e) {
		System.out.println("password field is not dispalyed");
	}
}

@Then("^I verify the \"([^\"]*)\" in step$")
public void i_verify_the_in_step(String arg1) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	Assert.assertTrue(driver.getCurrentUrl().contains("facebook"));
}





}
