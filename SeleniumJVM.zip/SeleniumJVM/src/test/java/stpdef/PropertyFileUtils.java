package stpdef;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class PropertyFileUtils {
Properties pos=null;
	
	public static String getProperty(String propertyName) throws IOException
	{
		Properties prop= new Properties();
		FileInputStream fs= new FileInputStream(System.getProperty("user.dir")+"\\ConfigData.properties");
		// C:\Users\bajarangi.chaurasia\workspace\SeleniumJVM\src\test\java\step_def\config.Properties		
		prop.load(fs);
	//	C:\Users\bajarangi.chaurasia\workspace\SeleniumJVM\src\test\java\step_def\config.Properties
	
	 return prop.getProperty(propertyName);	
	}
}



